const AppHeader = () => {
    return (
        <div className="d-flex justify-content-center align-items-center text-center bg-primary text-white py-4">
            <h1>CSI205-L การพัฒนาโปรแกรมส่วนหน้า</h1>
        </div >
    );
}

export default AppHeader;